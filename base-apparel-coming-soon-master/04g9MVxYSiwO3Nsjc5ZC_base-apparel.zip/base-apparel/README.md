# Sketch Design File

Thanks for downloading this Sketch file. We really appreciate your support!

If you don't have Sketch you can use [Sketch Cloud Inspector](https://blog.sketchapp.com/introducing-cloud-inspector-free-developer-handoff-in-the-browser-59917220334a) in the browser to view the design. You don't even need a Sketch Cloud account to use it.

The Sketch Cloud URL for this design is: [https://sketch.cloud/s/3jljz](https://sketch.cloud/s/3jljz).

If you'd like to learn more about how you can use Sketch Cloud Inspector to view the design, you can [read our walkthrough](https://medium.com/frontend-mentor/how-to-use-sketch-cloud-inspector-to-view-challenge-designs-55426ff90a90).

We hope you enjoy the challenge!